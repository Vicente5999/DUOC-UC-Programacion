/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class guias {
    private String nombre;
    public guias(String nombre) {

        this.nombre = "";
    }

    public String getNombre() {
        return nombre;
    } 
    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }
    
    @Override
    public String toString() {
        return "-- Nuevo Guia Turistico: -- \n " + "Nombre:" + nombre; 
    }
}
