/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class empleados {
    private String cargo;
    private String nombre;
    private direccion direccion;
 
    public empleados(String cargo, String nombre) {
        this.cargo = "";
        this.nombre = "";
        this.direccion = direccion;
    }
    
    public String getCargo() {
        return cargo;
    } 
    public void setCargo(String nuevocargo) {
        cargo = nuevocargo;
    }
    public String getNombre() {
        return nombre;
    } 
    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }
    public direccion getDireccion() {
        return direccion;
    } 
    public void setDireccion(direccion nuevaDireccion) {
        direccion = nuevaDireccion;
    }

    @Override
    public String toString() {
        return "-- Nuevo Empleado: -- \n " + "Nombre:" + nombre; 
    }
}