/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class proveedores {
    private String nombre;
    
    public proveedores(String nombre) {
        this.nombre = "";
    }
    
    public String getNombre() {
        return nombre;
    } 
    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }
    
    @Override
    public String toString() {
        return "-- Nuevo Proveedor: -- \n " + "Nombre:" + nombre;
    }   
}
