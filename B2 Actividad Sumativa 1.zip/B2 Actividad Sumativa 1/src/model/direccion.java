/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class direccion {
    private String calle;
    private int numero;
    private int casa;
    private String comuna;
    private String ciudad;
    
    public direccion(String calle, int numero, String ciudad, String comuna, int casa) {
        this.calle = "";
        this.numero = 0;
        this.casa = 0;
        this.comuna = "";
        this.ciudad = "";
    }
    
    public String getCalle() {
        return calle;
    } 
    public void setCalle(String nuevaCalle) {
        calle = nuevaCalle;
    }
    
    public int getNumero() {
        return numero;
    } 
    public void setNumero(int nuevoNumero) {
        numero = nuevoNumero;
    }
    public int getCasa() {
        return casa;
    } 
    public void setCasa (int nuevaCasa) {
        casa = nuevaCasa;
    }
    public String getComuna() {
        return comuna;
    } 
    public void setComuna(String nuevaComuna) {
        comuna = nuevaComuna;
    }
    
    public String getCiudad() {
        return ciudad;
    } 
    public void setCiudad(String nuevaCiudad) {
        ciudad = nuevaCiudad;
    }

    @Override
    public String toString() {
        return calle + " " + numero + ", " + "casa " + casa + ", " + comuna + ", " + ciudad;
    }
}