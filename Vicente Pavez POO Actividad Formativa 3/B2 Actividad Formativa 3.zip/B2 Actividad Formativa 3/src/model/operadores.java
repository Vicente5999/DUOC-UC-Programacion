/*
 * Representa a un operador local de Llanquihue Tour
 * Contiene el atributo de nombre
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class operadores {
    private String nombre;
    
    public operadores(String nombre) {
        this.nombre = "";
    }

    public String getNombre() {
        return nombre;
    } 
    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }
    
    @Override
    public String toString() {
        return "-- Nuevo Operador Local: -- \n " + "Nombre:" + nombre;
    }
}
