/*
 * Representa a un cliente de Llanquihue Tour
 * Contiene atributos como nombre y apellido
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class clientes {
    private String nombre;
    private String apellido;
    
    
    public clientes(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
    public String getNombre() {
        return nombre;
    } 
    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }
    public String getApellido() {
        return apellido;
    } 
    public void setApellido(String nuevoApellido) {
        apellido = nuevoApellido;
    }
    
    @Override
    public String toString() {
        return "-- Nuevo Cliente: -- \n " + "Nombre:" + nombre + " " + apellido;
    }    
}