/*
 * Representa a un guia turistico de Llanquihue Tour
 * Contiene el atributo de nombre
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class guias {
    private String nombre;
    
    public guias(String nombre) {
        this.nombre = "";
    }

    public String getNombre() {
        return nombre;
    } 
    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }
    
    @Override
    public String toString() {
        return "-- Nuevo Guia Turistico: -- \n " + "Nombre:" + nombre; 
    }
}
