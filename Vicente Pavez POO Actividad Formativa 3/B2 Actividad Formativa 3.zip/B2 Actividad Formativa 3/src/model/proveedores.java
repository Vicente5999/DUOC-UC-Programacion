/*
 * Representa a un proveedor de alojamiento y transporte Llanquihue Tour
 * Contiene atributos el atributo de nombre
 */
package model;

/**
 *
 * @author Vicente Pavez
 */
public class proveedores {
    private String nombre;
    
    public proveedores(String nombre) {
        this.nombre = "";
    }
    
    public String getNombre() {
        return nombre;
    } 
    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }
    
    @Override
    public String toString() {
        return "-- Nuevo Proveedor: -- \n " + "Nombre:" + nombre;
    }   
}
