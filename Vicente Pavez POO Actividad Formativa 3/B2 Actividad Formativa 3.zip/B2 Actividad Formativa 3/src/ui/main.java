/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ui;

import data.GestorDatos;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import model.clientes;
import model.direccion;
import model.empleados;
import model.guias;
import model.operadores;
import model.proveedores;

public class main {

   public static void main(String[] args) {
        
        direccion registroDireccion = new direccion("", 0, "", "", 0);
        clientes registroCliente = new clientes("", "");
        empleados registroEmpleados = new empleados("", "");
        guias registroGuias = new guias("");
        operadores registroOperadores = new operadores("");
        proveedores registroProveedores = new proveedores("");
        
        int cantidadClientes = 1;
        
        try (Scanner input = new Scanner(System.in)) {
            // Registro de Cliente
            System.out.println("\n--- Registro Cliente ---");
            System.out.println("Ingrese nombre del cliente:");
            registroCliente.setNombre(input.nextLine());
            System.out.println("Ingrese apellido del cliente:");
            registroCliente.setApellido(input.nextLine());
            
            System.out.println("-- Direccion del cliente: --");
            System.out.println("Ingrese calle del cliente:");
            registroDireccion.setCalle(input.nextLine());
            
            System.out.println("Ingrese numero de la calle del cliente:");
            registroDireccion.setNumero(input.nextInt());
            input.nextLine(); 
            boolean opcionValida = false; 
            
            do {
                System.out.println("¿Su casa es condominio o departamento? (si/no):");
                String esCondominio = input.nextLine();
                
                if (esCondominio.equalsIgnoreCase("si")) {
                    System.out.println("Ingrese numero de casa/depto del cliente:");
                    registroDireccion.setCasa(input.nextInt());
                    input.nextLine(); 
                    opcionValida = true; 
                    
                } else if (esCondominio.equalsIgnoreCase("no")) {
                    System.out.println("Ingrese comuna del cliente:");
                    registroDireccion.setComuna(input.nextLine());
                    System.out.println("Ingrese ciudad del cliente:");
                    registroDireccion.setCiudad(input.nextLine());
                    opcionValida = true;
                    
                } else {
                    System.out.println("Opcion no valida. Por favor, ingrese 'si' o 'no'.\n");      
                }
                
            } while (!opcionValida);
            // Registro de empleado
            opcionValida = false;
            do {
                System.out.println("¿Desea registrar a un empleado? (si/no):");
                String regEmpleado = input.nextLine();
                
                if (regEmpleado.equalsIgnoreCase("si")) {
                    System.out.println("\n--- Registro Empleado ---");
                    System.out.println("Ingrese nombre del empleado:");
                    registroEmpleados.setNombre(input.nextLine());
                    System.out.println("Ingrese cargo del empleado:");
                    registroEmpleados.setCargo(input.nextLine());
                    opcionValida = true;
                } else if (regEmpleado.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    System.out.println("Opcion no valida. Por favor, ingrese 'si' o 'no'.\n");
                }
            } while (!opcionValida);

            // Registro de Guía Turistíco
            opcionValida = false;
            do {
                System.out.println("¿Desea registrar a un guia turistico? (si/no):");
                String regGuia = input.nextLine();
                
                if (regGuia.equalsIgnoreCase("si")) {
                    System.out.println("\n--- Registro Guia Turistico ---");
                    System.out.println("Ingrese nombre del Guia Turistico:");
                    registroGuias.setNombre(input.nextLine());
                    opcionValida = true;
                } else if (regGuia.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    System.out.println("Opcion no valida. Por favor, ingrese 'si' o 'no'.\n");
                }
            } while (!opcionValida);

            // Registro de Operador Local
            opcionValida = false;
            do {
                System.out.println("¿Desea registrar a un Operador Local? (si/no):");
                String regOperador = input.nextLine();
                
                if (regOperador.equalsIgnoreCase("si")) {
                    System.out.println("\n--- Registro Operador Local ---");
                    System.out.println("Ingrese nombre del operador:");
                    registroOperadores.setNombre(input.nextLine());
                    opcionValida = true;
                } else if (regOperador.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    System.out.println("Opcion no valida. Por favor, ingrese 'si' o 'no'.\n");
                }
            } while (!opcionValida);

            // Registro de un Proveedor
            opcionValida = false;
            do {
                System.out.println("¿Desea registrar a un Proveedor? (si/no):");
                String regProveedor = input.nextLine();
                
                if (regProveedor.equalsIgnoreCase("si")) {
                    System.out.println("\n--- Registro Proveedor de Alojamiento y Transporte ---");
                    System.out.println("Ingrese nombre del proveedor:");
                    registroProveedores.setNombre(input.nextLine());
                    opcionValida = true;
                } else if (regProveedor.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    System.out.println("Opcion no valida. Por favor, ingrese 'si' o 'no'.\n");
                }
            } while (!opcionValida);
            
            // Resultados Finales
            System.out.println("\n--- Resumen de Registros ---");
            if (!registroCliente.getNombre().isEmpty() || !registroCliente.getApellido().isEmpty()) System.out.println(registroCliente.toString());
            System.out.println("Direccion: " + registroDireccion.toString());
            if (!registroEmpleados.getNombre().isEmpty()) System.out.println(registroEmpleados.toString());
            if (!registroGuias.getNombre().isEmpty()) System.out.println(registroGuias.toString());
            if (!registroOperadores.getNombre().isEmpty()) System.out.println(registroOperadores.toString());
            if (!registroProveedores.getNombre().isEmpty()) System.out.println(registroProveedores.toString());
            
            GestorDatos.datosTour(
                registroCliente.getNombre(),
                registroEmpleados.getNombre(),
                registroGuias.getNombre(), 
                registroOperadores.getNombre(), 
                registroProveedores.getNombre()
            );
              
      // Ver registro completo
            opcionValida = false; 
            do {
                System.out.println("\n¿Desea ver el registro completo guardado en el archivo? (si/no):");
                String verResultadoFinal = input.nextLine();
                
                if (verResultadoFinal.equalsIgnoreCase("si")) {
                    System.out.println("\n--- Registro Completo Llanquihue Tour ---");
                    System.out.println(" Nombre Clientes - Nombre Empleados - Nombre Guias - Nombre Operadores - Nombre Proveedores ");

                    try {
                        File archivo = new File(GestorDatos.archivoDatos);
                        Scanner lectorArchivo = new Scanner(archivo);

                        while (lectorArchivo.hasNextLine()) {
                            String linea = lectorArchivo.nextLine();
                            System.out.println(linea);
                        }
                        lectorArchivo.close();
                        
                    } catch (FileNotFoundException e) {
                        System.out.println("Error: No se encontró el archivo de registros. Asegúrese de que se haya guardado correctamente.");
                    }
                    
                    opcionValida = true;
                } else if (verResultadoFinal.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    System.out.println("Opcion no valida. Por favor, ingrese 'si' o 'no'.\n");
                } 
            } while (!opcionValida);
            
            // Filtrar por nombre
            opcionValida = false;
            do {
                System.out.println("\n¿Desea buscar un nombre especifico en el registro? (si/no):");
                String opcionBusqueda = input.nextLine();
                
                if (opcionBusqueda.equalsIgnoreCase("si")) {
                    System.out.println("Ingrese el nombre que desea buscar:");
                    String nombreBuscado = input.nextLine().toLowerCase();
                    
                    System.out.println("\n--- Resultados de Busqueda ---");
                    
                    try {
                        File archivo = new File(GestorDatos.archivoDatos);
                        Scanner lectorArchivo = new Scanner(archivo);
                        boolean encontroResultados = false;
                        
                        while (lectorArchivo.hasNextLine()) {
                            String linea = lectorArchivo.nextLine();

                            if (linea.toLowerCase().contains(nombreBuscado)) {
                                System.out.println("Registro encontrado: " + linea);
                                encontroResultados = true;
                            }
                        }
                        lectorArchivo.close();
                        
                        if (!encontroResultados) {
                            System.out.println("No se encontraron registros que coincidan con el nombre: " + nombreBuscado);
                        }
                        
                    } catch (FileNotFoundException e) {
                        System.out.println("Error: No se encontró el archivo de registros. Asegúrese de que se haya guardado correctamente.");
                    } 
                    
                    opcionValida = true;
            
                } else if (opcionBusqueda.equalsIgnoreCase("no")) {
                    opcionValida = true;
                    System.out.println("Saliendo del programa.");
                    System.exit(0);
                } else {
                    System.out.println("Opcion no valida. Por favor, ingrese 'si' o 'no'.\n");
                }
            } while (!opcionValida);
        }            
    }
}