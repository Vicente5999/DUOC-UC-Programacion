/*
 * Representa a la orden de compra de un cliente de Llanquihue Tour
 * Contiene los atributos de nombre y precio además del formato correcto para su uso
 */

package model;

/**
 *
 * @author Vicente5999 (GitHub)
 */

public class Producto {
    private String nombre;
    private float precio;

    public Producto(String nombreProducto, int precioProducto) {
        this.nombre = nombreProducto;
        this.precio = precioProducto;
    }

    public String getProducto() {
        return nombre;
    }

    public void setProducto(String nuevoProducto) {
        nombre = nuevoProducto;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float nuevoPrecio) {
        precio = nuevoPrecio;
    }

    @Override
    public String toString() {
        return "Producto: " + nombre + " Precio: " + precio;
    }
}