/*
 * Representa al RUT de un trabajador o cliente de Llanquihue Tour
 * Contiene el atributo de numRUT y la condición necesaria para su uso
 */

package model;

/**
 *
 * @author Vicente5999 (GitHub)
 */

public class RUT {

    private String numero;

    public RUT (String numRUT) {
        if (!numRUT.matches("[0-9]+-[0-9kK]")) {
            throw new IllegalArgumentException("Formato de Rut no valido.");
        }
        this.numero = numRUT;
    }

    public String getRUT() {
        return numero;
    }

    public void setRUT(String nuevoRUT) {
        this.numero = nuevoRUT;
    }

    @Override
    public String toString() {
        return "RUT: " + numero;
    }
}
