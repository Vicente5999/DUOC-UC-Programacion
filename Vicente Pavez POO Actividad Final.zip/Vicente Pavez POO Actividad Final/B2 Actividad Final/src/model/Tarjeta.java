/*
 * Representa a una tajeta de debito o credito de un cliente de Llanquihue Tour
 * Contiene el atributo de numTarjeta y la condición necesaria para su uso
 */

package model;

/**
 *
 * @author Vicente5999 (GitHub)
 */

public class Tarjeta {
    private String numero;

    public Tarjeta (String numTarjeta) {
        if (!numTarjeta.matches("(\\d{4}) {3}\\d{4}")) {
            throw new IllegalArgumentException("Formato de Rut no valido.");
        }
        this.numero = numTarjeta;
    }

    public String getTarjeta() {
        return numero;
    }

    public void setTarjeta(String numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Tarjeta: " + numero;
    }
}
