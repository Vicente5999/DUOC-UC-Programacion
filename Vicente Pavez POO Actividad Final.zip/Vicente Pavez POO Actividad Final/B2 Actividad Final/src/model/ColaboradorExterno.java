package model;

public class ColaboradorExterno implements Registrable {
    private String nombre;

    public ColaboradorExterno(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }

    @Override
    public void Registrar() {
        System.out.println("\n -- Registro de ColaboradorExterno: -- \n " + "Nombre: " + nombre);
    }

    @Override
    public void mostrarResumen() {
        System.out.println("\n -- ColaboradorExterno: -- \n " + "Nombre: " + nombre);
    }
}
