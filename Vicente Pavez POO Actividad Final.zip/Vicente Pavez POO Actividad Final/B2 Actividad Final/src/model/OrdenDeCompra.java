/*
 * Representa a la orden de compra de un cliente de Llanquihue Tour
 * Contiene el atributo de orden y el formato correcto para su uso
 */

package model;

/**
 *
 * @author Vicente5999 (GitHub)
 */

public class OrdenDeCompra extends Clientes {
    private String orden;
    private String producto;
    private float precio;

    public OrdenDeCompra(String orden, String nombre, String apellido, Direccion direccion, String producto, float precio) {
        super(nombre, apellido, direccion);
        this.orden = orden;
        this.producto = producto;
        this.precio = precio;
    }

    public String getOrden() {
        return orden;
    }

    public void setOrden(String nuevaOrden) {
        orden = nuevaOrden;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String nuevoProducto) {
        producto = nuevoProducto;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float nuevoPrecio) {
        precio = nuevoPrecio;
    }

    @Override
    public String toString() {
        return "\n -- Orden de Compra: -- \n" + "Nombre: " + getNombre() + " " + getApellido() + "\n" + "Producto: " + producto +  "\n" + "Precio: " + precio;
    }
}