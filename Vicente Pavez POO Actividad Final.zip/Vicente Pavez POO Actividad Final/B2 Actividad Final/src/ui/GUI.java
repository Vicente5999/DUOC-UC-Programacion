/*
 * Representa a una interfaz grafica para registra nuevos objetos
 * Contiene el codigo necesario para registrar Tours, Clientes, Empleados, Guías Turisticos, Operadores Locales y Proveedores de Llanquihue Tour
 * Incluye un sistema de visualización de registros y busqueda de registros por nombre
 * También puedes modificar los registros en un archivo txt ubicado en "resources/tours.txt" los cuales están separados mediante el caracter ";"
 */

package ui;

/**
 *
 * @author Vicente5999 (GitHub)
 */

import model.*;

import javax.swing.JOptionPane;

public class GUI {
    public static void main(String[] args) {

        try {
            String nombreCliente = JOptionPane.showInputDialog(null, "Ingresa el nombre del Cliente:");
            if (nombreCliente == null) return; // Si cancela, termina el programa

            String apellidoCliente = JOptionPane.showInputDialog(null, "Ingresa el apellido del Cliente:");
            if (apellidoCliente == null) return;

            String calleCliente = JOptionPane.showInputDialog(null, "Ingresa la calle del Cliente:");
            if (calleCliente == null) return;

            String numeroCalleCliente = JOptionPane.showInputDialog(null, "Ingresa el numero de la calle:");
            if (numeroCalleCliente == null) return;

            int numCalleCliente = Integer.parseInt(numeroCalleCliente);
            int casaCliente = 0;
            boolean opcionValida = false;

            do {
                String esCondominio = JOptionPane.showInputDialog(null, "¿Su dirección contiene número de condominio o departamento? (si/no):");
                if (esCondominio == null) return;

                if (esCondominio.equalsIgnoreCase("si")) {
                    casaCliente = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese numero de casa/depto del Cliente:"));
                    opcionValida = true;
                } else if (esCondominio.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, ingrese 'si' o 'no'.", "Atención", JOptionPane.WARNING_MESSAGE);
                }
            } while (!opcionValida);

            String comunaCliente = JOptionPane.showInputDialog(null, "Ingrese comuna del Cliente:");
            if (comunaCliente == null) return;

            String ciudadCliente = JOptionPane.showInputDialog(null, "Ingrese ciudad del Cliente:");
            if (ciudadCliente == null) return;

            String cargoEmpleado = JOptionPane.showInputDialog(null, "Ingresa el cargo del Empleado:");
            if (cargoEmpleado == null) return;

            String nombreEmpleado = JOptionPane.showInputDialog(null, "Ingresa el nombre del Empleado:");
            if (nombreEmpleado == null) return;

            String apellidoEmpleado = JOptionPane.showInputDialog(null, "Ingresa el apellido del Empleado:");
            if (apellidoEmpleado == null) return;

            String calleEmpleado = JOptionPane.showInputDialog(null, "Ingresa la calle del Empleado:");
            if (calleEmpleado == null) return;

            String numeroCalleEmpleado = JOptionPane.showInputDialog(null, "Ingresa el numero de la calle del Empleado:");
            if (numeroCalleEmpleado == null) return;

            int numCalleEmpleado = Integer.parseInt(numeroCalleEmpleado);
            int casaEmpleado = 0;
            opcionValida = false;

            do {
                String esCondominio = JOptionPane.showInputDialog(null, "¿Su dirección contiene número de condominio o departamento? (si/no):");
                if (esCondominio == null) return;

                if (esCondominio.equalsIgnoreCase("si")) {
                    casaEmpleado = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese numero de casa/depto del Empleado:"));
                    opcionValida = true;
                } else if (esCondominio.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, ingrese 'si' o 'no'.", "Atención", JOptionPane.WARNING_MESSAGE);
                }
            } while (!opcionValida);

            String comunaEmpleado = JOptionPane.showInputDialog(null, "Ingrese comuna del Empleado:");
            if (comunaEmpleado == null) return;

            String ciudadEmpleado = JOptionPane.showInputDialog(null, "Ingrese ciudad del Empleado:");
            if (ciudadEmpleado == null) return;

            String nombreGuia = JOptionPane.showInputDialog(null, "Ingresa el nombre del Guia Turistico:");
            if (nombreGuia == null) return;

            String apellidoGuia = JOptionPane.showInputDialog(null, "Ingresa el apellido del Guia Turistico:");
            if (apellidoGuia == null) return;

            String calleGuia = JOptionPane.showInputDialog(null, "Ingresa la calle del Guia Turistico:");
            if (calleGuia == null) return;

            String numeroCalleGuia = JOptionPane.showInputDialog(null, "Ingresa el numero de la calle:");
            if (numeroCalleGuia == null) return;

            int numCalleGuia = Integer.parseInt(numeroCalleGuia);
            int casaGuia = 0;
            opcionValida = false;

            do {
                String esCondominio = JOptionPane.showInputDialog(null, "¿Su dirección contiene número de condominio o departamento? (si/no):");
                if (esCondominio == null) return;

                if (esCondominio.equalsIgnoreCase("si")) {
                    casaGuia = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese numero de casa/depto del Guia Turistico:"));
                    opcionValida = true;
                } else if (esCondominio.equalsIgnoreCase("no")) {
                    opcionValida = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, ingrese 'si' o 'no'.", "Atención", JOptionPane.WARNING_MESSAGE);
                }
            } while (!opcionValida);

            String comunaGuia = JOptionPane.showInputDialog(null, "Ingrese comuna del Guia Turistico:");
            if (comunaGuia == null) return;

            String ciudadGuia = JOptionPane.showInputDialog(null, "Ingrese ciudad del Guia Turistico:");
            if (ciudadGuia == null) return;

            String modeloVehiculo = JOptionPane.showInputDialog(null, "Ingresa el modelo del Vehiculo:");
            if (modeloVehiculo == null) return;

            String tipoVehiculo = JOptionPane.showInputDialog(null, "Ingresa el tipo de Vehiculo:");
            if (tipoVehiculo == null) return;

            Direccion direccionClientes = new Direccion(calleCliente, numCalleCliente, ciudadCliente, comunaCliente, casaCliente);
            Direccion direccionEmpleados = new Direccion(calleEmpleado, numCalleEmpleado, ciudadEmpleado, comunaEmpleado, casaEmpleado);
            Direccion direccionGuia = new Direccion(calleGuia, numCalleGuia, ciudadGuia, comunaGuia, casaGuia);
            Clientes nuevoCliente = new Clientes(nombreCliente, apellidoCliente, direccionClientes);
            Empleados nuevoEmpleado = new Empleados(cargoEmpleado, nombreEmpleado, apellidoEmpleado, direccionEmpleados);

            GuiaTuristico nuevoGuia = new GuiaTuristico(nombreGuia, apellidoGuia, direccionGuia);
            Vehiculo nuevoVehiculo = new Vehiculo(modeloVehiculo, tipoVehiculo);

            // Mostrar el resultado final

            JOptionPane.showMessageDialog(
                    null,
                    "Nuevo Cliente registrado exitosamente\n\n" + nuevoCliente.toString(),
                    "Resumen del Registro de Cliente",
                    JOptionPane.INFORMATION_MESSAGE
            );

            JOptionPane.showMessageDialog(
                    null,
                    "Nuevo Empleado registrado exitosamente\n\n" + nuevoEmpleado.toString(),
                    "Resumen del Registro de Empleado",
                    JOptionPane.INFORMATION_MESSAGE
            );

            JOptionPane.showMessageDialog(
                    null,
                    "Nuevo Guia Turistico registrado exitosamente\n\n" + nuevoGuia.toString(),
                    "Resumen del Registro de Guia Turistico",
                    JOptionPane.INFORMATION_MESSAGE
            );

            JOptionPane.showMessageDialog(
                    null,
                    "Nuevo Vehiculo registrado exitosamente\n\n" + nuevoVehiculo.toString(),
                    "Resumen del Registro de Vehiculo",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error: Debes ingresar números válidos en el número de calle y de casa.",
                    "Error de formato",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}